# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name :data
   Description :处理获取数据，传递给相关图表，避免多次读取文件
   Author :Liu
   date：2017/11/28
-------------------------------------------------
"""
__author__ = 'Liu'




def get_data_wordcloud():
    data_dict = {}
    # 添加表数据：
    html_before = '''
            <div class="bs-docs-section"> 
        	<h1 id="我是ID1" class="page-header">
        	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: BT2" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; line-height: inherit; position: absolute; margin-left: -1em; padding-right: 0.5em;"></a>
        	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: third parties" data-anchorjs-icon="" style="font-family: anchorjs-icons;
                                                font-style: normal; font-variant-ligatures: normal;
                                                font-variant-caps: normal; font-weight: normal;
                                                line-height: inherit; position: absolute; margin-left: -1em;
                                                padding-right: 0.5em;">
             </a>商品评论热词分析
            </h1>
            <p class="lead">分别在服饰鞋包、数码、配饰、家居用品几类中挑选出样本商品对其商品评论内容中的高频词进行分析，以词云方式展现买家注重商品的哪些方面
        </p>
        	<div class="my-charts">
        	'''

    html_after = '''
        </div>
    	<p class="lead"></p>
    	<h2 id="我是ID1.1">
    	<a class="anchorjs-link " href="#我是ID1.1" aria-label="Anchor link for: third box sizing" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; line-height: inherit; position: absolute; margin-left: -1em; padding-right: 0.5em;"></a>
        <a class="anchorjs-link " href="#我是ID1.1" aria-label="Anchor link for: third box sizing" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal;
                                        font-variant-ligatures: normal; font-variant-caps: normal;
                                        font-weight: normal; line-height: inherit; position: absolute;
                                        margin-left: -1em; padding-right: 0.5em;">

        </a>
    	</h2>
        '''
    html_after1 = '''
            <div class="bs-docs-section"> 
        	<h1 id="我是ID1" class="page-header">
        	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: BT2" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; line-height: inherit; position: absolute; margin-left: -1em; padding-right: 0.5em;"></a>
        	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: third parties" data-anchorjs-icon="" style="font-family: anchorjs-icons;
                                                font-style: normal; font-variant-ligatures: normal;
                                                font-variant-caps: normal; font-weight: normal;
                                                line-height: inherit; position: absolute; margin-left: -1em;
                                                padding-right: 0.5em;">
             </a>
            </h1>
            <p class="lead">
        </p>
        	<div class="my-charts">
        	'''

    words1 = []
    values1 = []
    with open(r'app/all_data_files/all_data_files/rateContent/dress.txt', 'r', encoding='utf-8') as f:
        for line in f:
            temp = line.split('，')
            words1.append(temp[0])
            value1 = temp[1].split('\n')
            values1.append(value1[0])
    data_dict['charcloud1'] = [html_before, html_after, words1, values1]

    words2 = []
    values2 = []
    with open(r'app/all_data_files/all_data_files/rateContent/storagebox.txt', 'r', encoding='utf-8') as f:
        for line in f:
            temp = line.split('，')
            words2.append(temp[0])
            value2 = temp[1].split('\n')
            values2.append(value2[0])
    data_dict['charcloud2'] = [html_before, html_after, words2, values2]

    words3 = []
    values3 = []
    with open(r'app/all_data_files/all_data_files/rateContent/subwoofers.txt', 'r', encoding='utf-8') as f:
        for line in f:
            temp = line.split('，')
            words3.append(temp[0])
            value3 = temp[1].split('\n')
            values3.append(value3[0])
    data_dict['charcloud3'] = [html_before, html_after, words3, values3]

    words4 = []
    values4 = []
    with open(r'app/all_data_files/all_data_files/rateContent/sunglass.txt', 'r', encoding='utf-8') as f:
        for line in f:
            temp = line.split('，')
            words4.append(temp[0])
            value4 = temp[1].split('\n')
            values4.append(value4[0])
    data_dict['charcloud4'] = [html_before, html_after, words4, values4]

    return data_dict


def get_data_shangpin():
    data_year = {}
    # 添加表数据：
    html_before = '''
            <div class="bs-docs-section"> 
        	<h1 id="我是ID1" class="page-header">
        	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: BT2" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; line-height: inherit; position: absolute; margin-left: -1em; padding-right: 0.5em;"></a>
        	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: third parties" data-anchorjs-icon="" style="font-family: anchorjs-icons;
                                                font-style: normal; font-variant-ligatures: normal;
                                                font-variant-caps: normal; font-weight: normal;
                                                line-height: inherit; position: absolute; margin-left: -1em;
                                                padding-right: 0.5em;">
             </a>2017年度和2018年度商品质量分析
            </h1>
            <p class="lead">2017年度和2018年度商品评论对比分析，近段时间以来该商品的质量状况
        </p>
        	<div class="my-charts">
        	'''

    html_after = '''
        </div>
    	<p class="lead"></p>
    	<h2 id="我是ID1.1">
    	<a class="anchorjs-link " href="#我是ID1.1" aria-label="Anchor link for: third box sizing" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; line-height: inherit; position: absolute; margin-left: -1em; padding-right: 0.5em;"></a>
        <a class="anchorjs-link " href="#我是ID1.1" aria-label="Anchor link for: third box sizing" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal;
                                        font-variant-ligatures: normal; font-variant-caps: normal;
                                        font-weight: normal; line-height: inherit; position: absolute;
                                        margin-left: -1em; padding-right: 0.5em;">

        </a>
    	</h2>
        '''
    html_after1 = '''
            <div class="bs-docs-section"> 
        	<h1 id="我是ID1" class="page-header">
        	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: BT2" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; line-height: inherit; position: absolute; margin-left: -1em; padding-right: 0.5em;"></a>
        	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: third parties" data-anchorjs-icon="" style="font-family: anchorjs-icons;
                                                font-style: normal; font-variant-ligatures: normal;
                                                font-variant-caps: normal; font-weight: normal;
                                                line-height: inherit; position: absolute; margin-left: -1em;
                                                padding-right: 0.5em;">
             </a>
            </h1>
            <p class="lead">
        </p>
        	<div class="my-charts">
        	'''

    words1 = []
    values1 = []
    with open(r'app/all_data_files/all_data_files/rateContent/2017year.txt', 'r', encoding='utf-8') as f1:
        for line in f1:
            temp = line.split('：')
            words1.append(temp[0])
            value1 = temp[1].split('\n')
            values1.append(value1[0])
        data_year['cloud1'] = [html_before, html_after, words1, values1]

    words2 = []
    values2 = []
    with open(r'app/all_data_files/all_data_files/rateContent/2018year.txt', 'r', encoding='utf-8') as f2:
        for line in f2:
            temp = line.split('：')
            words2.append(temp[0])
            value2 = temp[1].split('\n')
            values2.append(value1[0])
        data_year['cloud2'] = [html_before, html_after, words2, values2]

    return data_year