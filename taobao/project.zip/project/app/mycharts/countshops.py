from pyecharts import Bar, Line, Liquid, WordCloud, Pie, Overlap, Page, Style, Radar, Page, Style, Line, Map, Polar, Geo, EffectScatter
from app.mycharts.constants import WIDTH, HEIGHT

def create_charts1():
    html = ''
    page = Page()
    style = Style(width=900, height=600)
    html_before ='''
                    <div class="bs-docs-section"> 
                	<h1 id="我是ID1" class="page-header">
                	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: BT2" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; line-height: inherit; position: absolute; margin-left: -1em; padding-right: 0.5em;"></a>
                	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: third parties" data-anchorjs-icon="" style="font-family: anchorjs-icons;
                                                        font-style: normal; font-variant-ligatures: normal;
                                                        font-variant-caps: normal; font-weight: normal;
                                                        line-height: inherit; position: absolute; margin-left: -1em;
                                                        padding-right: 0.5em;">
                     </a>店铺数量饱和度
                    </h1>
                  
                	<div class="my-charts">
                	'''
    html_after = ''

    attr = ['数码', '车品配件', '服饰鞋包', '家居用品', '家装家饰','美容护理','母婴','食品','配饰','其他行业']
    es = EffectScatter("店铺数量饱和度")
    es.add("数码", [1], [23005.6], symbol_size=35, effect_scale=3.5, effect_period=3, symbol="pin")
    es.add("车品配件", [2], [3929.48], symbol_size=20, effect_scale=4.5, effect_period=4, symbol="rect")
    es.add("服饰鞋包", [3], [84493.43], symbol_size=55, effect_scale=5.5, effect_period=5, symbol="roundRect")
    es.add("家居用品", [4], [25277.33], symbol_size=45, effect_scale=4.5, effect_brushtype='fill', symbol="diamond")
    es.add("家装家饰", [5], [10194.28], symbol_size=25, effect_scale=3.5, effect_period=3, symbol="arrow")
    es.add("美容护理", [6], [2175.6], symbol_size=20, effect_scale=3.5, effect_period=3, symbol="pin")
    es.add("母婴", [7], [34388.48], symbol_size=50, effect_scale=4.5, effect_period=4, symbol="rect")
    es.add("食品", [8], [15951.43], symbol_size=30, effect_scale=3.5, effect_period=5, symbol="roundRect")
    es.add("配饰", [9], [1045.33], symbol_size=10, effect_scale=1.5, effect_brushtype='fill', symbol="diamond")
    es.add("其他行业", [10], [24528.28], symbol_size=40,effect_scale=5.5, effect_period=3, symbol="arrow")
    es.render()
    java_script = es.render_embed()
    html += html_before + java_script + html_after
    page.add(es)
    script = page.get_js_dependencies()
    return html, script