# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name :shangpin
   Description :
   Author :Liu
   date：2018/01/19
-------------------------------------------------
"""

from pyecharts import Bar, Line, Liquid, WordCloud, Pie, Overlap, Page, Style, Radar, Page, Style, Line, Map, Polar, Geo, EffectScatter
from app.mycharts.constants import WIDTH, HEIGHT


def create_charts(data):
    html = ''
    page = Page()
    style = Style(width=900, height=600)
    # 表一2017年商品评论中的高频词
    html_before = ""
    html_after = data['cloud1'][1]
    chars = data['cloud1'][2]
    values = data['cloud1'][3]
    wordcloud1 = WordCloud("2017热词", **style.init_style)
    wordcloud1.add("2017年度", chars, values, word_size_range=[10, 100], shape='pentagon')
    java_script = wordcloud1.render_embed()
    html += html_before + java_script + html_after
    page.add(wordcloud1)

    # 表四-2018年商品评论中的高频词
    html_before = ""
    html_after = data['cloud2'][1]
    chars = data['cloud2'][2]
    values = data['cloud2'][3]
    wordcloud2 = WordCloud("2018热词", **style.init_style)
    wordcloud2.add("2018年度", chars, values, word_size_range=[10, 100], shape='pentagon')
    java_script = wordcloud2.render_embed()
    html += html_before + java_script + html_after
    page.add(wordcloud2)

    # 最后
    script = page.get_js_dependencies()
    return html, script