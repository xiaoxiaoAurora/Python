# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name :shopgrades
   Description :
   Author :Liu
   date：2018/01/19
-------------------------------------------------
"""
__author__ = 'Liu'

from pyecharts import Bar, Line, Liquid, WordCloud, Pie, Overlap, Page, Style,Radar



def create_charts(data):
    html = ''
    page = Page()
    style = Style(width=900, height=600)
    # 表4淘宝店铺生存状态的分析与可视化
    html_before = '''
                    <div class="bs-docs-section"> 
                	<h1 id="我是ID1" class="page-header">
                	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: BT2" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; line-height: inherit; position: absolute; margin-left: -1em; padding-right: 0.5em;"></a>
                	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: third parties" data-anchorjs-icon="" style="font-family: anchorjs-icons;
                                                        font-style: normal; font-variant-ligatures: normal;
                                                        font-variant-caps: normal; font-weight: normal;
                                                        line-height: inherit; position: absolute; margin-left: -1em;
                                                        padding-right: 0.5em;">
                     </a>淘宝店铺生存状态的分析与可视化
                    </h1>
                    <p class="lead">根据淘宝店铺等级以及所占店铺总数的比例，可视化呈现出淘宝店铺的生存状态。
                </p>
                	<div class="my-charts">
                	'''
    html_after = ''

    attr = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I']
    v1 = [11616,8892, 42118, 63409, 79721, 16419, 2755, 85, 802]
    bar = Bar("淘宝店铺等级以及所占店铺总数的比例")
    bar.add("bar", attr, v1)
    bar.show_config()
    bar.render()
    java_script = bar.render_embed()
    html += html_before + java_script + html_after
    page.add(bar)
    # 最后
    script = page.get_js_dependencies()
    return html, script