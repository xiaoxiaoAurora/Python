# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name :ShiRenGuanXi
   Description :
   Author :Liangs
   date：2017/12/4
-------------------------------------------------
"""


from pyecharts import Map, Pie, Funnel, Page, Style
import random

def create_charts(data):
    html = ''
    page = Page()
    style = Style(width=900, height=600)
    # 表一:
    html_before = '''
                  <div class="bs-docs-section"> 
              	<h1 id="我是ID1" class="page-header">
              	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: BT2" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; line-height: inherit; position: absolute; margin-left: -1em; padding-right: 0.5em;"></a>
              	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: third parties" data-anchorjs-icon="" style="font-family: anchorjs-icons;
                                                      font-style: normal; font-variant-ligatures: normal;
                                                      font-variant-caps: normal; font-weight: normal;
                                                      line-height: inherit; position: absolute; margin-left: -1em;
                                                      padding-right: 0.5em;">
                   </a>
                  </h1>
                  <p class="lead">淘宝商家地址的全国分布图，可看出沿海江浙一带是比较盛行的，西藏、新疆等西部地区很少开淘宝店.                      
              </p>
              	<div class="my-charts">
              	'''
    html_after = ''
    value = [1152,25,6453,3951,54,17652,459,85,49,1948,1757,351,1504,1099,270,6577,973,1463,142,14,12,3619,303,394,8063,1280,75,548,6,281,233,284,16518,431]
    attr = ["安徽","澳门","北京","福建","甘肃","广东","广西","贵州","海南","河北","河南","黑龙江","湖北","湖南","吉林","江苏","江西","辽宁","内蒙古","宁夏","青海","山东","山西","陕西","上海","四川","台湾","天津","西藏","香港","新疆","云南","浙江","重庆"]
    map = Map("全国店铺分布", width=1200, height=600)
    map.add("", attr, value, maptype='china', is_visualmap=True, visual_text_color='#000',visual_range=[0,20000])
    java_script = map.render_embed()
    html += html_before + java_script + html_after
    page.add(map)

    #表二-各类店铺的区域性（服饰）

    html_before = '''
                      <div class="bs-docs-section"> 
                  	<h1 id="我是ID1" class="page-header">
                  	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: BT2" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; line-height: inherit; position: absolute; margin-left: -1em; padding-right: 0.5em;"></a>
                  	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: third parties" data-anchorjs-icon="" style="font-family: anchorjs-icons;
                                                          font-style: normal; font-variant-ligatures: normal;
                                                          font-variant-caps: normal; font-weight: normal;
                                                          line-height: inherit; position: absolute; margin-left: -1em;
                                                          padding-right: 0.5em;">
                       </a>
                      </h1>

                      <p class="lead">
                  </p>
                  	<div class="my-charts"> 

                  	'''

    pie = Pie("", title_pos='center', width=1000, height=600)
    attr=['广东', '浙江', '湖北', '重庆', '北京', '江苏']
    v1 = [6389,6220,2167,1934,1929,1875]
    pie.add("", attr, v1, is_label_show=True)
    pie.show_config()
    pie.render()
    page.add(pie)
    java_script = pie.render_embed()
    html += html_before + java_script + html_after

#表三（食品）
    html_before = '''
                      <div class="bs-docs-section"> 
                  	<h1 id="我是ID1" class="page-header">
                  	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: BT2" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; line-height: inherit; position: absolute; margin-left: -1em; padding-right: 0.5em;"></a>
                  	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: third parties" data-anchorjs-icon="" style="font-family: anchorjs-icons;
                                                          font-style: normal; font-variant-ligatures: normal;
                                                          font-variant-caps: normal; font-weight: normal;
                                                          line-height: inherit; position: absolute; margin-left: -1em;
                                                          padding-right: 0.5em;">
                       </a>
                      </h1>

                      <p class="lead">
                  </p>
                  	<div class="my-charts"> 

                  	'''
    attr =["浙江", "广东", "北京","福建", "山东","江苏"]
    pie = Pie("食品分布", width=1000, height=600)
    v1 =[437, 627, 636, 735, 842, 691]
    pie.add("商品B", attr, v1, center=[50, 50], is_random=True, radius=[30, 75], rosetype='area',
            is_legend_show=False, is_label_show=True)
    pie.show_config()
    pie.render()
    java_script = pie.render_embed()
    html += html_before + java_script + html_after

    # 表三（母婴）
    html_before = '''
                         <div class="bs-docs-section"> 
                     	<h1 id="我是ID1" class="page-header">
                     	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: BT2" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; line-height: inherit; position: absolute; margin-left: -1em; padding-right: 0.5em;"></a>
                     	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: third parties" data-anchorjs-icon="" style="font-family: anchorjs-icons;
                                                             font-style: normal; font-variant-ligatures: normal;
                                                             font-variant-caps: normal; font-weight: normal;
                                                             line-height: inherit; position: absolute; margin-left: -1em;
                                                             padding-right: 0.5em;">
                          </a>
                         </h1>

                         <p class="lead">
                     </p>
                     	<div class="my-charts"> 

                     	'''
    attr = ['北京', '广东', '浙江', '广西', '吉林', '江西']
    value = [437, 627, 636, 735, 842, 691]
    funnel = Funnel("漏斗图示例")
    funnel.add("商品", attr, value, is_label_show=True, label_pos="inside", label_text_color="#fff")
    funnel.render()
    java_script = funnel.render_embed()
    html += html_before + java_script + html_after
    script = page.get_js_dependencies()
    return html, script
