# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name :shangjiaxinxi
   Description :
   Author :Liu
   date：2018/01/19
-------------------------------------------------
"""
__author__ = 'Liu'

from pyecharts import Bar, Line, Liquid, WordCloud, Pie, Overlap, Page, Style,Radar
# -*- coding: utf-8 -*-
"""
-------------------------------------------------
   File Name :shopprovn
   Description :
   Author :Liu
   date：2018/01/19
-------------------------------------------------
"""

def create_charts(data):
    html = ''
    page = Page()
    style = Style(width=900, height=600)

    # 表1.5-1服饰鞋包店铺销量排序
    html_before = '''
                    <div class="bs-docs-section"> 
                	<h1 id="我是ID1" class="page-header">
                	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: BT2" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; line-height: inherit; position: absolute; margin-left: -1em; padding-right: 0.5em;"></a>
                	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: third parties" data-anchorjs-icon="" style="font-family: anchorjs-icons;
                                                        font-style: normal; font-variant-ligatures: normal;
                                                        font-variant-caps: normal; font-weight: normal;
                                                        line-height: inherit; position: absolute; margin-left: -1em;
                                                        padding-right: 0.5em;">
                     </a>店铺性价比
                    </h1>
                    <p class="lead">根据每品类店铺销量进行排序，结合其好评率综合分析，选出每类商品性价比较高的店铺（排名前5家），并可向消费者定向推荐。
                </p>
                
                	<div class="my-charts">
                	'''
    html_after = ''
    shops = ['可可里小姐', '问香坊', '港仔文艺男', '黑眼豆豆zhou', '小宅女大购物' ]
    attr = ["{}".format(i) for i in shops]
    v1 = [526099, 346426, 343551, 312377, 283091]
    v2 = [519259, 344555, 339806, 310502, 279071]
    bar = Bar("服饰鞋包店铺销量排序")
    bar.add("销量", attr, v1, mark_line=["average"], mark_point=["max", "min"])
    bar.add("好评*600000", attr, v2, mark_line=["average"], mark_point=["max", "min"])
    bar.show_config()
    bar.render()
    java_script = bar.render_embed()
    html += html_before + java_script + html_after
    page.add(bar)

    # 表1.5-2珠宝/配饰店铺销量排序
    html_before = '''
                      <div class="bs-docs-section"> 
                  	<h1 id="我是ID1" class="page-header">
                  	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: BT2" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; line-height: inherit; position: absolute; margin-left: -1em; padding-right: 0.5em;"></a>
                  	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: third parties" data-anchorjs-icon="" style="font-family: anchorjs-icons;
                                                          font-style: normal; font-variant-ligatures: normal;
                                                          font-variant-caps: normal; font-weight: normal;
                                                          line-height: inherit; position: absolute; margin-left: -1em;
                                                          padding-right: 0.5em;">
                       </a>店铺性价比
                      </h1>
                      <p class="lead">根据每品类店铺销量进行排序，结合其好评率综合分析，选出每类商品性价比较高的店铺（排名前5家），并可向消费者定向推荐。
                  </p>
                  	<div class="my-charts">
                  	'''
    html_after = ''
    shops = ['酷儿饰品精品商城', '平价饰品第一店', '小饰易妆韩国发饰头饰包邮', '喔啦啦欧韩饰品 专注饰品7年', '卉然韩国饰品发饰']
    attr = ["{}".format(i) for i in shops]
    v1 = [1003794, 796507, 719047, 516216, 508330]
    v2 = [984420, 781453, 716458, 509092, 505585]
    bar = Bar("珠宝/配饰店铺销量排序")
    bar.add("销量", attr, v1, mark_line=["average"], mark_point=["max", "min"])
    bar.add("好评*600000", attr, v2, mark_line=["average"], mark_point=["max", "min"])
    bar.show_config()
    bar.render()
    java_script = bar.render_embed()
    html += html_before + java_script + html_after
    page.add(bar)
    # 最后
    script = page.get_js_dependencies()
    return html, script