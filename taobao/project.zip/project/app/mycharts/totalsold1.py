from pyecharts import Radar, Page, Style,Line,Pie,Map,Polar,WordCloud,Geo,EffectScatter, Polar

def create_charts(data):
    html = ''
    page = Page()
    style = Style(width=900, height=600)
    html_before = '''
                        <div class="bs-docs-section"> 
                    	<h1 id="我是ID1" class="page-header">
                    	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: BT2" data-anchorjs-icon="" style="font-family: anchorjs-icons; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: normal; line-height: inherit; position: absolute; margin-left: -1em; padding-right: 0.5em;"></a>
                    	<a class="anchorjs-link " href="#我是ID1" aria-label="Anchor link for: third parties" data-anchorjs-icon="" style="font-family: anchorjs-icons;
                                                            font-style: normal; font-variant-ligatures: normal;
                                                            font-variant-caps: normal; font-weight: normal;
                                                            line-height: inherit; position: absolute; margin-left: -1em;
                                                            padding-right: 0.5em;">
                         </a>不同种类店铺的店铺销量
                        </h1>
                        <p class="lead">对每一类不同销量阶段的商家店铺进行统计分析，能得到同一类商品的不同销量阶段的分布以及同一阶段的不同商品的占比，可看出不同种类商家的经营状况.
                    	<div class="my-charts">
                    	'''
    html_after = ''
    radius = ['0-100', '101-500', '501-1000', '1001-5000', '5000-1万', '1万-50万', '50万以上']
    polar = Polar("销售阶段", width=900, height=600)
    polar.add("服饰鞋包", [16739, 25710, 14273, 22490, 3218, 2062, 1], radius_data=radius, type='barAngle',
              is_stack=True)
    polar.add("家居用品", [6641, 7900, 3004, 5582, 1209, 930, 11], radius_data=radius, type='barAngle',
              is_stack=True)
    polar.add("母婴", [9731, 11457, 4476, 6842, 1133, 749, 0], radius_data=radius, type='barAngle', is_stack=True)
    polar.add("数码", [4148, 8778, 3878, 4889, 731, 579, 2], radius_data=radius, type='barAngle',
              is_stack=True)
    polar.add("食品", [4636, 3340, 1921, 4544, 818, 92, 1], radius_data=radius, type='barAngle', is_stack=True)
    polar.add("配饰", [177, 96, 77, 370, 147, 174, 5], radius_data=radius, type='barAngle', is_stack=True)
    java_script = polar.render_embed()
    html += html_before + java_script + html_after
    page.add(polar)
    # 最后
    script = page.get_js_dependencies()
    return html, script