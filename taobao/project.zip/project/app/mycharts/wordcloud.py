
from pyecharts import Bar, Line, Liquid, WordCloud, Pie, Overlap, Page, Style,EffectScatter



def create_charts(data):
    #表一
    html = ''
    page = Page()
    style = Style(width=900, height=500)
    #表一-主题词
    html_before = ""
    html_after = data['charcloud1'][1]
    chars = data['charcloud1'][2]
    values = data['charcloud1'][3]
    wordcloud1 = WordCloud("dress词云", **style.init_style)
    wordcloud1.add("dress词云", chars, values, word_size_range=[10, 200], shape='pentagon')
    java_script = wordcloud1.render_embed()
    html += html_before + java_script + html_after
    page.add(wordcloud1)
    # 表一-主题词
    html_before = ""
    html_after = data['charcloud2'][1]
    chars = data['charcloud2'][2]
    values = data['charcloud2'][3]
    wordcloud2 = WordCloud("subwoofers词云", **style.init_style)
    wordcloud2.add("subwoofers词云", chars, values, word_size_range=[10, 200], shape='pentagon')
    java_script = wordcloud2.render_embed()
    html += html_before + java_script + html_after
    page.add(wordcloud2)
    # 表一-主题词
    html_before = ""
    html_after = data['charcloud3'][1]
    chars = data['charcloud3'][2]
    values = data['charcloud3'][3]
    wordcloud3 = WordCloud("sunglass词云", **style.init_style)
    wordcloud3.add("sunglass词云", chars, values, word_size_range=[10, 200], shape='pentagon')
    java_script = wordcloud3.render_embed()
    html += html_before + java_script + html_after
    page.add(wordcloud3)
    # 表一-主题词
    html_before = ""
    html_after = data['charcloud4'][1]
    chars = data['charcloud4'][2]
    values = data['charcloud4'][3]
    wordcloud4 = WordCloud("storagebox词云", **style.init_style)
    wordcloud4.add("storagebox词云", chars, values, word_size_range=[10, 200], shape='pentagon')
    java_script = wordcloud4.render_embed()
    html += html_before + java_script + html_after
    page.add(wordcloud4)
    # 最后
    script = page.get_js_dependencies()
    return html, script